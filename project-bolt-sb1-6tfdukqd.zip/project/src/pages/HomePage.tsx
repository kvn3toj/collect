import React from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { 
  Box, 
  Container, 
  Typography, 
  Button, 
  Grid,
  Card,
  CardMedia,
  CardContent,
  useTheme,
  useMediaQuery,
  Divider
} from '@mui/material';
import { motion } from 'framer-motion';

// Hero section background image
const HERO_IMAGE = "https://images.pexels.com/photos/6766260/pexels-photo-6766260.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2";

const HomePage: React.FC = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const isSmall = useMediaQuery(theme.breakpoints.down('sm'));

  // Featured collection
  const featuredCollection = [
    {
      id: '1',
      name: 'Colombian Emerald Ring',
      price: 2499,
      image: 'https://images.pexels.com/photos/10961577/pexels-photo-10961577.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: '2',
      name: 'Emerald Teardrop Necklace',
      price: 3299,
      image: 'https://images.pexels.com/photos/12351222/pexels-photo-12351222.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: '3',
      name: 'Raw Emerald Bracelet',
      price: 1899,
      image: 'https://images.pexels.com/photos/5370706/pexels-photo-5370706.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: '4',
      name: 'Emerald Stud Earrings',
      price: 1499,
      image: 'https://images.pexels.com/photos/3266700/pexels-photo-3266700.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
  ];

  // Categories 
  const categories = [
    {
      name: 'Emerald Rings',
      image: 'https://images.pexels.com/photos/10961577/pexels-photo-10961577.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      link: '/products?category=rings',
    },
    {
      name: 'Emerald Necklaces',
      image: 'https://images.pexels.com/photos/12351222/pexels-photo-12351222.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      link: '/products?category=necklaces',
    },
    {
      name: 'Emerald Earrings',
      image: 'https://images.pexels.com/photos/3266700/pexels-photo-3266700.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      link: '/products?category=earrings',
    },
  ];

  return (
    <Box>
      {/* Hero Section */}
      <Box
        sx={{
          position: 'relative',
          height: { xs: '70vh', md: '80vh' },
          display: 'flex',
          alignItems: 'center',
          mb: 8,
          overflow: 'hidden',
        }}
      >
        <Box
          component="img"
          src={HERO_IMAGE}
          alt="Luxury emerald jewelry"
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            filter: 'brightness(0.8)',
            zIndex: -1,
          }}
        />
        <Container maxWidth="lg">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <Box
              sx={{
                maxWidth: { xs: '100%', md: '60%' },
                color: 'white',
                position: 'relative',
                zIndex: 1,
              }}
            >
              <Typography
                variant="h1"
                component="h1"
                sx={{
                  fontSize: { xs: '2.5rem', md: '4rem' },
                  mb: 2,
                  fontWeight: 700,
                  textShadow: '0px 2px 4px rgba(0,0,0,0.3)',
                }}
              >
                Exquisite Emeralds for Extraordinary People
              </Typography>
              <Typography
                variant="h6"
                sx={{
                  mb: 4,
                  maxWidth: '700px',
                  textShadow: '0px 1px 2px rgba(0,0,0,0.3)',
                  fontWeight: 400,
                }}
              >
                Discover our collection of rare Colombian emeralds and luxury jewelry pieces, meticulously crafted for those who appreciate exceptional beauty.
              </Typography>
              <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                <Button
                  component={RouterLink}
                  to="/products"
                  variant="contained"
                  color="primary"
                  size="large"
                  sx={{
                    px: 4,
                    py: 1.5,
                    fontSize: '1rem',
                    fontWeight: 600,
                  }}
                >
                  Explore Collection
                </Button>
                <Button
                  component={RouterLink}
                  to="/customize"
                  variant="outlined"
                  size="large"
                  sx={{
                    px: 4,
                    py: 1.5,
                    fontSize: '1rem',
                    fontWeight: 600,
                    backgroundColor: 'rgba(255, 255, 255, 0.15)',
                    borderColor: 'white',
                    color: 'white',
                    '&:hover': {
                      backgroundColor: 'rgba(255, 255, 255, 0.25)',
                      borderColor: 'white',
                    },
                  }}
                >
                  Custom Design
                </Button>
              </Box>
            </Box>
          </motion.div>
        </Container>
      </Box>

      {/* Featured Products Section */}
      <Container maxWidth="lg" sx={{ mb: 10 }}>
        <Box sx={{ textAlign: 'center', mb: 6 }}>
          <Typography
            variant="h2"
            component="h2"
            sx={{
              fontFamily: "'Playfair Display', serif",
              fontSize: { xs: '2rem', md: '2.75rem' },
              mb: 2,
            }}
          >
            Featured Collection
          </Typography>
          <Typography
            variant="body1"
            color="text.secondary"
            sx={{ maxWidth: '700px', mx: 'auto' }}
          >
            Our most cherished pieces, handcrafted with ethically sourced emeralds and precious metals.
          </Typography>
        </Box>

        <Grid container spacing={3}>
          {featuredCollection.map((product) => (
            <Grid item xs={12} sm={6} md={3} key={product.id}>
              <motion.div
                whileHover={{ y: -8, transition: { duration: 0.3 } }}
              >
                <Card
                  component={RouterLink}
                  to={`/products/${product.id}`}
                  sx={{
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                    textDecoration: 'none',
                    borderRadius: 0,
                    boxShadow: 'none',
                    border: '1px solid',
                    borderColor: 'divider',
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      boxShadow: '0 8px 24px rgba(0, 0, 0, 0.12)',
                    },
                  }}
                >
                  <CardMedia
                    component="img"
                    image={product.image}
                    alt={product.name}
                    sx={{
                      height: 260,
                      objectFit: 'cover',
                    }}
                  />
                  <CardContent sx={{ flexGrow: 1, textAlign: 'center' }}>
                    <Typography
                      variant="subtitle1"
                      component="div"
                      sx={{ mb: 1, color: 'text.primary' }}
                    >
                      {product.name}
                    </Typography>
                    <Typography
                      variant="body2"
                      color="text.secondary"
                      fontWeight={600}
                    >
                      ${product.price.toLocaleString()}
                    </Typography>
                  </CardContent>
                </Card>
              </motion.div>
            </Grid>
          ))}
        </Grid>

        <Box sx={{ textAlign: 'center', mt: 5 }}>
          <Button
            component={RouterLink}
            to="/products"
            variant="outlined"
            color="primary"
            size="large"
            sx={{
              px: 5,
              py: 1.5,
              fontWeight: 600,
            }}
          >
            View All Products
          </Button>
        </Box>
      </Container>

      {/* About Our Emeralds Section */}
      <Box sx={{ backgroundColor: '#f5f5f5', py: 8, mb: 10 }}>
        <Container maxWidth="lg">
          <Grid container spacing={4} alignItems="center">
            <Grid item xs={12} md={6}>
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <Typography
                  variant="h3"
                  component="h2"
                  sx={{
                    mb: 3,
                    fontFamily: "'Playfair Display', serif",
                  }}
                >
                  The ARETrust Difference
                </Typography>
                <Typography variant="body1" sx={{ mb: 3 }}>
                  Each emerald in our collection is carefully selected for its exceptional color, clarity, and character. We specialize in rare Colombian emeralds known for their intense green color and unique inclusions that tell the story of their formation.
                </Typography>
                <Typography variant="body1" sx={{ mb: 4 }}>
                  Our gemologists travel directly to mines in Colombia to personally select stones that meet our exacting standards. Every emerald is ethically sourced, ensuring that our pieces not only look beautiful but also support sustainable mining practices.
                </Typography>
                <Button
                  component={RouterLink}
                  to="/about"
                  variant="outlined"
                  color="primary"
                  sx={{ fontWeight: 600 }}
                >
                  Learn About Our Process
                </Button>
              </motion.div>
            </Grid>
            <Grid item xs={12} md={6}>
              <Box
                sx={{
                  position: 'relative',
                  height: { xs: 300, md: 400 },
                  overflow: 'hidden',
                }}
              >
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                >
                  <Box
                    component="img"
                    src="https://images.pexels.com/photos/3917867/pexels-photo-3917867.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                    alt="Raw emerald gemstones"
                    sx={{
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                    }}
                  />
                </motion.div>
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>

      {/* Categories Section */}
      <Container maxWidth="lg" sx={{ mb: 10 }}>
        <Box sx={{ textAlign: 'center', mb: 6 }}>
          <Typography
            variant="h2"
            component="h2"
            sx={{
              fontFamily: "'Playfair Display', serif",
              fontSize: { xs: '2rem', md: '2.75rem' },
              mb: 2,
            }}
          >
            Shop by Category
          </Typography>
          <Typography
            variant="body1"
            color="text.secondary"
            sx={{ maxWidth: '700px', mx: 'auto' }}
          >
            Find the perfect emerald piece for every occasion and style.
          </Typography>
        </Box>

        <Grid container spacing={3}>
          {categories.map((category, index) => (
            <Grid item xs={12} md={4} key={index}>
              <motion.div
                whileHover={{ y: -8, transition: { duration: 0.3 } }}
              >
                <Box
                  component={RouterLink}
                  to={category.link}
                  sx={{
                    position: 'relative',
                    height: 380,
                    overflow: 'hidden',
                    display: 'block',
                    textDecoration: 'none',
                    '&:hover img': {
                      transform: 'scale(1.05)',
                    },
                    '&:hover .overlay': {
                      backgroundColor: 'rgba(0, 0, 0, 0.3)',
                    },
                  }}
                >
                  <Box
                    component="img"
                    src={category.image}
                    alt={category.name}
                    sx={{
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                      transition: 'transform 0.6s ease',
                    }}
                  />
                  <Box
                    className="overlay"
                    sx={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: '100%',
                      height: '100%',
                      backgroundColor: 'rgba(0, 0, 0, 0.4)',
                      display: 'flex',
                      justifyContent: 'center',
                      alignItems: 'center',
                      transition: 'background-color 0.3s ease',
                    }}
                  >
                    <Typography
                      variant="h4"
                      sx={{
                        color: 'white',
                        fontWeight: 600,
                        textShadow: '0px 2px 4px rgba(0,0,0,0.3)',
                      }}
                    >
                      {category.name}
                    </Typography>
                  </Box>
                </Box>
              </motion.div>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* Custom Design CTA Section */}
      <Box
        sx={{
          background: `linear-gradient(rgba(11, 93, 76, 0.9), rgba(11, 93, 76, 0.9)), url(https://images.pexels.com/photos/1493320/pexels-photo-1493320.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2)`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          py: 8,
          mb: 10,
        }}
      >
        <Container maxWidth="md">
          <Box sx={{ textAlign: 'center', color: 'white' }}>
            <Typography
              variant="h3"
              component="h2"
              sx={{
                mb: 3,
                fontFamily: "'Playfair Display', serif",
              }}
            >
              Create Your Perfect Emerald Piece
            </Typography>
            <Typography variant="h6" sx={{ mb: 4, fontWeight: 400 }}>
              Work with our expert designers to craft a bespoke jewelry piece that tells your unique story.
            </Typography>
            <Button
              component={RouterLink}
              to="/customize"
              variant="contained"
              color="secondary"
              size="large"
              sx={{
                px: 5,
                py: 1.5,
                fontSize: '1rem',
                fontWeight: 600,
              }}
            >
              Start Your Custom Design
            </Button>
          </Box>
        </Container>
      </Box>

      {/* Testimonials Section */}
      <Container maxWidth="lg" sx={{ mb: 10 }}>
        <Box sx={{ textAlign: 'center', mb: 6 }}>
          <Typography
            variant="h2"
            component="h2"
            sx={{
              fontFamily: "'Playfair Display', serif",
              fontSize: { xs: '2rem', md: '2.75rem' },
              mb: 2,
            }}
          >
            What Our Clients Say
          </Typography>
          <Typography
            variant="body1"
            color="text.secondary"
            sx={{ maxWidth: '700px', mx: 'auto' }}
          >
            Hear from clients who have experienced the ARETrust difference.
          </Typography>
        </Box>

        <Grid container spacing={4}>
          <Grid item xs={12} md={4}>
            <Card sx={{ height: '100%', borderRadius: 0, boxShadow: 'none', border: '1px solid', borderColor: 'divider' }}>
              <CardContent sx={{ p: 4 }}>
                <Typography variant="body1" sx={{ mb: 3, fontStyle: 'italic' }}>
                  "The emerald engagement ring I purchased exceeded all my expectations. The stone's color is breathtaking, and my fiancée was completely stunned. ARETrust's customer service made the selection process effortless."
                </Typography>
                <Divider sx={{ my: 3 }} />
                <Typography variant="subtitle1" fontWeight={600}>
                  Michael R.
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  New York, NY
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={4}>
            <Card sx={{ height: '100%', borderRadius: 0, boxShadow: 'none', border: '1px solid', borderColor: 'divider' }}>
              <CardContent sx={{ p: 4 }}>
                <Typography variant="body1" sx={{ mb: 3, fontStyle: 'italic' }}>
                  "Working with the design team to create a custom emerald pendant was a wonderful experience. They took the time to understand exactly what I wanted and delivered a piece that I'll treasure forever. Truly exceptional craftsmanship."
                </Typography>
                <Divider sx={{ my: 3 }} />
                <Typography variant="subtitle1" fontWeight={600}>
                  Sophia J.
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Los Angeles, CA
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={4}>
            <Card sx={{ height: '100%', borderRadius: 0, boxShadow: 'none', border: '1px solid', borderColor: 'divider' }}>
              <CardContent sx={{ p: 4 }}>
                <Typography variant="body1" sx={{ mb: 3, fontStyle: 'italic' }}>
                  "As a collector of fine gemstones, I'm extremely particular about quality. The Colombian emeralds from ARETrust are simply extraordinary - their color saturation and clarity are remarkable. I've become a loyal customer."
                </Typography>
                <Divider sx={{ my: 3 }} />
                <Typography variant="subtitle1" fontWeight={600}>
                  David M.
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Chicago, IL
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Container>

      {/* Instagram Feed Section (Mock) */}
      <Container maxWidth="lg" sx={{ mb: 10 }}>
        <Box sx={{ textAlign: 'center', mb: 5 }}>
          <Typography
            variant="h2"
            component="h2"
            sx={{
              fontFamily: "'Playfair Display', serif",
              fontSize: { xs: '2rem', md: '2.75rem' },
              mb: 2,
            }}
          >
            Follow Our Journey
          </Typography>
          <Typography
            variant="body1"
            color="text.secondary"
            sx={{ maxWidth: '700px', mx: 'auto', mb: 2 }}
          >
            Discover the world of ARETrust on Instagram
          </Typography>
          <Typography
            variant="subtitle1"
            fontWeight={600}
            sx={{ color: theme.palette.primary.main }}
          >
            @aretrust_emeralds
          </Typography>
        </Box>

        <Grid container spacing={1}>
          {[
            'https://images.pexels.com/photos/5370706/pexels-photo-5370706.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            'https://images.pexels.com/photos/7988462/pexels-photo-7988462.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            'https://images.pexels.com/photos/10961577/pexels-photo-10961577.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            'https://images.pexels.com/photos/12351222/pexels-photo-12351222.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            'https://images.pexels.com/photos/7988247/pexels-photo-7988247.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            'https://images.pexels.com/photos/8285167/pexels-photo-8285167.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          ].map((image, index) => (
            <Grid item xs={4} sm={2} key={index}>
              <motion.div
                whileHover={{ opacity: 0.8 }}
                transition={{ duration: 0.3 }}
              >
                <Box
                  sx={{
                    position: 'relative',
                    paddingTop: '100%', // 1:1 Aspect Ratio
                    overflow: 'hidden',
                    cursor: 'pointer',
                  }}
                >
                  <Box
                    component="img"
                    src={image}
                    alt="Instagram post"
                    sx={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                    }}
                  />
                </Box>
              </motion.div>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* Newsletter Section */}
      <Box sx={{ backgroundColor: '#f5f5f5', py: 8 }}>
        <Container maxWidth="md">
          <Box sx={{ textAlign: 'center' }}>
            <Typography
              variant="h3"
              component="h2"
              sx={{
                mb: 3,
                fontFamily: "'Playfair Display', serif",
              }}
            >
              Join Our Community
            </Typography>
            <Typography variant="body1" sx={{ mb: 4, maxWidth: '600px', mx: 'auto' }}>
              Subscribe to our newsletter for exclusive offers, new arrivals, and expert insights into the world of fine emeralds and jewelry.
            </Typography>
            <Box
              component="form"
              sx={{
                display: 'flex',
                flexDirection: { xs: 'column', sm: 'row' },
                justifyContent: 'center',
                gap: 1,
                maxWidth: '500px',
                mx: 'auto',
              }}
            >
              <Box sx={{ flexGrow: 1, minWidth: { xs: '100%', sm: 'auto' } }}>
                <TextField
                  fullWidth
                  placeholder="Your email address"
                  variant="outlined"
                  sx={{
                    backgroundColor: 'white',
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 0,
                    },
                  }}
                />
              </Box>
              <Button
                variant="contained"
                color="primary"
                size="large"
                sx={{
                  py: 1.5,
                  px: 4,
                  fontWeight: 600,
                  mt: { xs: 1, sm: 0 },
                  width: { xs: '100%', sm: 'auto' },
                }}
              >
                Subscribe
              </Button>
            </Box>
          </Box>
        </Container>
      </Box>
    </Box>
  );
};

export default HomePage;