import React from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Container,
  Typography,
  Box,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  Slider,
  Button,
} from '@mui/material';
import { productService } from '../services/productService';
import ProductGrid from '../components/products/ProductGrid';
import { ProductFilter } from '../types/product.types';

const ProductsPage: React.FC = () => {
  const [filters, setFilters] = React.useState<ProductFilter>({
    category: undefined,
    priceRange: [0, 10000],
    sortBy: 'newest',
  });

  const { data, isLoading, error } = useQuery({
    queryKey: ['products', filters],
    queryFn: () => productService.getAllProducts(filters),
  });

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      <Typography
        variant="h2"
        component="h1"
        sx={{
          mb: 4,
          fontFamily: "'Playfair Display', serif",
          textAlign: 'center',
        }}
      >
        Luxury Emerald Collection
      </Typography>

      <Grid container spacing={4}>
        {/* Filters Section */}
        <Grid item xs={12} md={3}>
          <Box sx={{ p: 3, border: '1px solid', borderColor: 'divider' }}>
            <Typography variant="h6" sx={{ mb: 3 }}>
              Filters
            </Typography>

            <Box sx={{ mb: 3 }}>
              <FormControl fullWidth size="small">
                <InputLabel>Category</InputLabel>
                <Select
                  value={filters.category || ''}
                  label="Category"
                  onChange={(e) =>
                    setFilters({ ...filters, category: e.target.value })
                  }
                >
                  <MenuItem value="">All Categories</MenuItem>
                  <MenuItem value="rings">Rings</MenuItem>
                  <MenuItem value="necklaces">Necklaces</MenuItem>
                  <MenuItem value="earrings">Earrings</MenuItem>
                  <MenuItem value="bracelets">Bracelets</MenuItem>
                </Select>
              </FormControl>
            </Box>

            <Box sx={{ mb: 3 }}>
              <Typography variant="subtitle2" gutterBottom>
                Price Range
              </Typography>
              <Slider
                value={filters.priceRange}
                onChange={(_, newValue) =>
                  setFilters({ ...filters, priceRange: newValue as [number, number] })
                }
                valueLabelDisplay="auto"
                min={0}
                max={10000}
                step={100}
              />
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <TextField
                    size="small"
                    label="Min"
                    value={filters.priceRange[0]}
                    onChange={(e) =>
                      setFilters({
                        ...filters,
                        priceRange: [Number(e.target.value), filters.priceRange[1]],
                      })
                    }
                    fullWidth
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    size="small"
                    label="Max"
                    value={filters.priceRange[1]}
                    onChange={(e) =>
                      setFilters({
                        ...filters,
                        priceRange: [filters.priceRange[0], Number(e.target.value)],
                      })
                    }
                    fullWidth
                  />
                </Grid>
              </Grid>
            </Box>

            <Box sx={{ mb: 3 }}>
              <FormControl fullWidth size="small">
                <InputLabel>Sort By</InputLabel>
                <Select
                  value={filters.sortBy || 'newest'}
                  label="Sort By"
                  onChange={(e) =>
                    setFilters({ ...filters, sortBy: e.target.value as ProductFilter['sortBy'] })
                  }
                >
                  <MenuItem value="newest">Newest</MenuItem>
                  <MenuItem value="price-asc">Price: Low to High</MenuItem>
                  <MenuItem value="price-desc">Price: High to Low</MenuItem>
                  <MenuItem value="popularity">Popularity</MenuItem>
                </Select>
              </FormControl>
            </Box>

            <Button
              variant="outlined"
              fullWidth
              onClick={() =>
                setFilters({
                  category: undefined,
                  priceRange: [0, 10000],
                  sortBy: 'newest',
                })
              }
            >
              Clear Filters
            </Button>
          </Box>
        </Grid>

        {/* Products Grid Section */}
        <Grid item xs={12} md={9}>
          <ProductGrid
            products={data?.products || []}
            isLoading={isLoading}
            error={error instanceof Error ? error : null}
          />
        </Grid>
      </Grid>
    </Container>
  );
};

export default ProductsPage;