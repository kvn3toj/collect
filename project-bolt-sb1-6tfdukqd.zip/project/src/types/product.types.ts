export interface Product {
  id: string;
  name: string;
  description: string;
  shortDescription: string;
  price: number;
  discountPrice?: number;
  images: string[];
  category: string;
  tags: string[];
  sku: string;
  stock: number;
  weight: number;
  dimensions?: {
    length: number;
    width: number;
    height: number;
  };
  features: string[];
  specifications: Record<string, string>;
  customizationOptions?: CustomizationOption[];
  createdAt: string;
  updatedAt: string;
}

export interface CustomizationOption {
  id: string;
  name: string;
  type: 'metal' | 'setting' | 'size' | 'engraving' | 'gemstone';
  options: {
    id: string;
    name: string;
    description?: string;
    image?: string;
    priceAdjustment: number;
  }[];
}

export interface ProductFilter {
  category?: string;
  priceRange?: [number, number];
  searchQuery?: string;
  sortBy?: 'price-asc' | 'price-desc' | 'newest' | 'popularity';
  tags?: string[];
  inStock?: boolean;
}

export interface CartItem {
  productId: string;
  product: Product;
  quantity: number;
  customizations?: Record<string, string>;
  totalPrice: number;
}

export interface ProductReview {
  id: string;
  productId: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  createdAt: string;
}