import React, { useState } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import {
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  Box,
  Rating,
  Skeleton,
  IconButton,
  useTheme,
} from '@mui/material';
import { ShoppingBag, Eye } from 'lucide-react';
import { Product } from '../../types/product.types';
import useCartStore from '../../stores/cartStore';
import { motion, AnimatePresence } from 'framer-motion';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> & { Skeleton: React.FC } = ({ product }) => {
  const theme = useTheme();
  const [isHovered, setIsHovered] = useState(false);
  const [imageError, setImageError] = useState(false);
  const { addItem } = useCartStore();

  const handleAddToCart = () => {
    addItem(product, 1);
  };

  return (
    <Card
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        position: 'relative',
        borderRadius: 0,
        boxShadow: 'none',
        border: '1px solid',
        borderColor: 'divider',
        transition: 'all 0.3s ease',
        '&:hover': {
          boxShadow: '0 8px 24px rgba(0, 0, 0, 0.12)',
        },
      }}
    >
      <Box sx={{ position: 'relative', paddingTop: '100%' }}>
        <CardMedia
          component="img"
          image={imageError ? '/placeholder-image.jpg' : product.images[0]}
          alt={product.name}
          onError={() => setImageError(true)}
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            objectFit: 'cover',
          }}
        />
        <AnimatePresence>
          {isHovered && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                background: 'rgba(0, 0, 0, 0.3)',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                gap: '8px',
              }}
            >
              <IconButton
                component={RouterLink}
                to={`/products/${product.id}`}
                sx={{
                  bgcolor: 'white',
                  '&:hover': { bgcolor: 'white', opacity: 0.9 },
                }}
              >
                <Eye size={20} />
              </IconButton>
              <IconButton
                onClick={handleAddToCart}
                sx={{
                  bgcolor: theme.palette.primary.main,
                  color: 'white',
                  '&:hover': {
                    bgcolor: theme.palette.primary.dark,
                  },
                }}
              >
                <ShoppingBag size={20} />
              </IconButton>
            </motion.div>
          )}
        </AnimatePresence>
      </Box>

      <CardContent sx={{ flexGrow: 1, p: 2 }}>
        <Typography
          variant="subtitle1"
          component={RouterLink}
          to={`/products/${product.id}`}
          sx={{
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
            textDecoration: 'none',
            color: 'text.primary',
            '&:hover': {
              color: 'primary.main',
            },
          }}
        >
          {product.name}
        </Typography>

        <Box sx={{ mt: 1, mb: 2 }}>
          <Rating value={4.5} precision={0.5} size="small" readOnly />
          <Typography variant="body2" color="text.secondary">
            (24 reviews)
          </Typography>
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 1 }}>
          {product.discountPrice && (
            <Typography
              variant="body1"
              color="error"
              sx={{ textDecoration: 'line-through' }}
            >
              ${product.price.toLocaleString()}
            </Typography>
          )}
          <Typography variant="h6" color="primary" fontWeight={600}>
            ${(product.discountPrice || product.price).toLocaleString()}
          </Typography>
        </Box>
      </CardContent>
    </Card>
  );
};

// Skeleton loader component
ProductCard.Skeleton = function ProductCardSkeleton() {
  return (
    <Card
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        borderRadius: 0,
        boxShadow: 'none',
        border: '1px solid',
        borderColor: 'divider',
      }}
    >
      <Skeleton
        variant="rectangular"
        sx={{ paddingTop: '100%' }}
      />
      <CardContent sx={{ flexGrow: 1, p: 2 }}>
        <Skeleton variant="text" sx={{ fontSize: '1.25rem', mb: 1 }} />
        <Skeleton variant="text" sx={{ fontSize: '1rem', width: '60%', mb: 2 }} />
        <Skeleton variant="text" sx={{ fontSize: '1.5rem', width: '40%' }} />
      </CardContent>
    </Card>
  );
};

export default ProductCard;