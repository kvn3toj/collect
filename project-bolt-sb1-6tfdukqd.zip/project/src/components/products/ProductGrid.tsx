import React from 'react';
import { Grid, Box } from '@mui/material';
import ProductCard from './ProductCard';
import { Product } from '../../types/product.types';
import { motion } from 'framer-motion';

interface ProductGridProps {
  products: Product[];
  isLoading?: boolean;
  error?: Error | null;
}

const ProductGrid: React.FC<ProductGridProps> = ({ products, isLoading, error }) => {
  if (error) {
    return (
      <Box sx={{ textAlign: 'center', py: 8 }}>
        <p>Error loading products: {error.message}</p>
      </Box>
    );
  }

  return (
    <Grid 
      container 
      spacing={{ xs: 2, md: 3 }}
      columns={{ xs: 1, sm: 8, md: 12 }}
    >
      {isLoading
        ? Array.from(new Array(6)).map((_, index) => (
            <Grid item xs={1} sm={4} md={4} key={`skeleton-${index}`}>
              <ProductCard.Skeleton />
            </Grid>
          ))
        : products.map((product) => (
            <Grid item xs={1} sm={4} md={4} key={product.id}>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <ProductCard product={product} />
              </motion.div>
            </Grid>
          ))}
    </Grid>
  );
};

export default ProductGrid;