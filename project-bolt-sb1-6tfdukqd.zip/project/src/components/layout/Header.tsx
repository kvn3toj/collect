import React, { useState, useEffect } from 'react';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import { 
  AppBar, 
  Toolbar, 
  Typography, 
  Button, 
  IconButton, 
  Badge, 
  Box, 
  Container, 
  Menu, 
  MenuItem, 
  Drawer, 
  List, 
  ListItem, 
  ListItemText, 
  Divider,
  useMediaQuery,
  Avatar,
  Fade
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import { ShoppingBag, User, Menu as MenuIcon, Heart, Search, X } from 'lucide-react';
import useAuthStore from '../../stores/authStore';
import useCartStore from '../../stores/cartStore';
import SearchBar from '../ui/SearchBar';
import { motion } from 'framer-motion';

const Header: React.FC = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const navigate = useNavigate();
  
  const { isAuthenticated, user, logout } = useAuthStore();
  const { items, openCart, getTotalItems } = useCartStore();
  
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userMenuAnchor, setUserMenuAnchor] = useState<null | HTMLElement>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  
  const cartItemCount = getTotalItems();
  const userMenuOpen = Boolean(userMenuAnchor);

  // Handle scroll effect for transparent header
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleUserMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setUserMenuAnchor(event.currentTarget);
  };

  const handleUserMenuClose = () => {
    setUserMenuAnchor(null);
  };

  const handleLogout = () => {
    logout();
    handleUserMenuClose();
    navigate('/');
  };

  const handleMobileMenuToggle = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const handleSearchToggle = () => {
    setSearchOpen(!searchOpen);
  };

  return (
    <AppBar 
      position="fixed" 
      color="transparent" 
      sx={{
        backgroundColor: isScrolled ? 'rgba(255, 255, 255, 0.95)' : 'transparent',
        boxShadow: isScrolled ? '0px 2px 10px rgba(0, 0, 0, 0.05)' : 'none',
        transition: 'all 0.3s ease',
        borderBottom: isScrolled ? '1px solid rgba(0, 0, 0, 0.1)' : 'none',
      }}
    >
      <Container maxWidth="xl">
        <Toolbar sx={{ py: 1 }}>
          {/* Mobile Menu Toggle */}
          {isMobile && (
            <IconButton
              color="inherit"
              edge="start"
              onClick={handleMobileMenuToggle}
              sx={{ mr: 1, color: theme.palette.text.primary }}
            >
              <MenuIcon />
            </IconButton>
          )}

          {/* Logo */}
          <Typography
            variant="h5"
            component={RouterLink}
            to="/"
            sx={{
              fontFamily: "'Playfair Display', serif",
              fontWeight: 700,
              color: theme.palette.primary.main,
              textDecoration: 'none',
              flexGrow: isMobile ? 1 : 0,
              textAlign: isMobile ? 'center' : 'left',
            }}
          >
            ARETrust
          </Typography>

          {/* Desktop Navigation Links */}
          {!isMobile && (
            <Box sx={{ mx: 4, display: 'flex', flexGrow: 1 }}>
              <Button 
                component={RouterLink} 
                to="/products" 
                color="inherit"
                sx={{ 
                  mx: 1.5,
                  color: theme.palette.text.primary,
                  '&:hover': {
                    backgroundColor: 'transparent',
                    color: theme.palette.primary.main,
                  }
                }}
              >
                Collections
              </Button>
              <Button 
                component={RouterLink} 
                to="/products?category=emeralds" 
                color="inherit"
                sx={{ 
                  mx: 1.5,
                  color: theme.palette.text.primary,
                  '&:hover': {
                    backgroundColor: 'transparent',
                    color: theme.palette.primary.main,
                  }
                }}
              >
                Emeralds
              </Button>
              <Button 
                component={RouterLink} 
                to="/products?category=jewelry" 
                color="inherit"
                sx={{ 
                  mx: 1.5,
                  color: theme.palette.text.primary,
                  '&:hover': {
                    backgroundColor: 'transparent',
                    color: theme.palette.primary.main,
                  }
                }}
              >
                Jewelry
              </Button>
              <Button 
                component={RouterLink} 
                to="/customize" 
                color="inherit"
                sx={{ 
                  mx: 1.5,
                  color: theme.palette.text.primary,
                  '&:hover': {
                    backgroundColor: 'transparent',
                    color: theme.palette.primary.main,
                  }
                }}
              >
                Custom Design
              </Button>
            </Box>
          )}

          {/* Right Icons Section */}
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <IconButton 
              color="inherit" 
              aria-label="search" 
              onClick={handleSearchToggle}
              sx={{ color: theme.palette.text.primary }}
            >
              <Search size={20} />
            </IconButton>
            
            {isAuthenticated && (
              <IconButton 
                component={RouterLink} 
                to="/account/wishlist" 
                color="inherit" 
                sx={{ ml: 1, color: theme.palette.text.primary }}
              >
                <Heart size={20} />
              </IconButton>
            )}
            
            <IconButton 
              color="inherit" 
              onClick={openCart} 
              sx={{ ml: 1, color: theme.palette.text.primary }}
            >
              <Badge badgeContent={cartItemCount} color="secondary">
                <ShoppingBag size={20} />
              </Badge>
            </IconButton>
            
            {isAuthenticated ? (
              <>
                <IconButton
                  onClick={handleUserMenuOpen}
                  sx={{ ml: 2 }}
                  aria-controls={userMenuOpen ? 'user-menu' : undefined}
                  aria-haspopup="true"
                  aria-expanded={userMenuOpen ? 'true' : undefined}
                >
                  <Avatar 
                    src={user?.avatar} 
                    alt={user?.firstName}
                    sx={{ 
                      width: 30, 
                      height: 30,
                      bgcolor: theme.palette.primary.main 
                    }}
                  >
                    {user?.firstName?.charAt(0)}
                  </Avatar>
                </IconButton>
                <Menu
                  id="user-menu"
                  anchorEl={userMenuAnchor}
                  open={userMenuOpen}
                  onClose={handleUserMenuClose}
                  TransitionComponent={Fade}
                  MenuListProps={{
                    'aria-labelledby': 'user-button',
                  }}
                  sx={{
                    '& .MuiPaper-root': {
                      borderRadius: 0,
                      boxShadow: '0px 5px 15px rgba(0, 0, 0, 0.08)',
                      mt: 1.5,
                    },
                  }}
                >
                  <MenuItem onClick={() => {
                    handleUserMenuClose();
                    navigate('/account');
                  }}>
                    My Account
                  </MenuItem>
                  <MenuItem onClick={() => {
                    handleUserMenuClose();
                    navigate('/account/orders');
                  }}>
                    My Orders
                  </MenuItem>
                  {user?.role === 'admin' && (
                    <MenuItem onClick={() => {
                      handleUserMenuClose();
                      navigate('/admin');
                    }}>
                      Admin Dashboard
                    </MenuItem>
                  )}
                  <Divider />
                  <MenuItem onClick={handleLogout}>Logout</MenuItem>
                </Menu>
              </>
            ) : (
              <Button
                component={RouterLink}
                to="/login"
                color="inherit"
                startIcon={<User size={18} />}
                sx={{ 
                  ml: 2,
                  color: theme.palette.text.primary,
                  '&:hover': {
                    backgroundColor: 'transparent',
                    color: theme.palette.primary.main,
                  }
                }}
              >
                Login
              </Button>
            )}
          </Box>
        </Toolbar>
      </Container>

      {/* Mobile Menu Drawer */}
      <Drawer
        anchor="left"
        open={mobileMenuOpen}
        onClose={handleMobileMenuToggle}
        sx={{
          '& .MuiDrawer-paper': {
            width: '80%',
            maxWidth: 300,
          },
        }}
      >
        <Box
          sx={{
            p: 2,
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <Typography
            variant="h6"
            sx={{
              fontFamily: "'Playfair Display', serif",
              fontWeight: 700,
              color: theme.palette.primary.main,
            }}
          >
            ARETrust
          </Typography>
          <IconButton onClick={handleMobileMenuToggle}>
            <X size={24} />
          </IconButton>
        </Box>
        <Divider />
        <List>
          <ListItem 
            button 
            component={RouterLink} 
            to="/products"
            onClick={handleMobileMenuToggle}
          >
            <ListItemText primary="Collections" />
          </ListItem>
          <ListItem 
            button 
            component={RouterLink} 
            to="/products?category=emeralds"
            onClick={handleMobileMenuToggle}
          >
            <ListItemText primary="Emeralds" />
          </ListItem>
          <ListItem 
            button 
            component={RouterLink} 
            to="/products?category=jewelry"
            onClick={handleMobileMenuToggle}
          >
            <ListItemText primary="Jewelry" />
          </ListItem>
          <ListItem 
            button 
            component={RouterLink} 
            to="/customize"
            onClick={handleMobileMenuToggle}
          >
            <ListItemText primary="Custom Design" />
          </ListItem>
          <Divider />
          
          {isAuthenticated ? (
            <>
              <ListItem 
                button 
                component={RouterLink} 
                to="/account"
                onClick={handleMobileMenuToggle}
              >
                <ListItemText primary="My Account" />
              </ListItem>
              <ListItem 
                button 
                component={RouterLink} 
                to="/account/orders"
                onClick={handleMobileMenuToggle}
              >
                <ListItemText primary="My Orders" />
              </ListItem>
              <ListItem 
                button 
                component={RouterLink} 
                to="/account/wishlist"
                onClick={handleMobileMenuToggle}
              >
                <ListItemText primary="Wishlist" />
              </ListItem>
              {user?.role === 'admin' && (
                <ListItem 
                  button 
                  component={RouterLink} 
                  to="/admin"
                  onClick={handleMobileMenuToggle}
                >
                  <ListItemText primary="Admin Dashboard" />
                </ListItem>
              )}
              <ListItem 
                button 
                onClick={() => {
                  logout();
                  handleMobileMenuToggle();
                }}
              >
                <ListItemText primary="Logout" />
              </ListItem>
            </>
          ) : (
            <ListItem 
              button 
              component={RouterLink} 
              to="/login"
              onClick={handleMobileMenuToggle}
            >
              <ListItemText primary="Login / Register" />
            </ListItem>
          )}
        </List>
      </Drawer>

      {/* Search Overlay */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ 
          opacity: searchOpen ? 1 : 0,
          y: searchOpen ? 0 : -20,
          display: searchOpen ? 'block' : 'none'
        }}
        transition={{ duration: 0.3 }}
        style={{
          position: 'absolute',
          top: '100%',
          left: 0,
          right: 0,
          backgroundColor: 'white',
          padding: '1rem',
          boxShadow: '0px 5px 15px rgba(0, 0, 0, 0.08)',
          zIndex: 10,
        }}
      >
        <Container maxWidth="lg">
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <SearchBar onClose={handleSearchToggle} />
            <IconButton onClick={handleSearchToggle} sx={{ ml: 1 }}>
              <X size={20} />
            </IconButton>
          </Box>
        </Container>
      </motion.div>
    </AppBar>
  );
};

export default Header;