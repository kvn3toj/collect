import React from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { Box, Typography, IconButton, Select, MenuItem, SelectChangeEvent } from '@mui/material';
import { X } from 'lucide-react';
import useCartStore from '../../stores/cartStore';
import { CartItem as CartItemType } from '../../types/product.types';

interface CartItemProps {
  item: CartItemType;
}

const CartItem: React.FC<CartItemProps> = ({ item }) => {
  const { removeItem, updateQuantity } = useCartStore();

  const handleQuantityChange = (event: SelectChangeEvent<number>) => {
    updateQuantity(item.productId, Number(event.target.value));
  };

  return (
    <Box
      sx={{
        display: 'flex',
        py: 2,
        borderBottom: '1px solid',
        borderColor: 'divider',
        '&:last-child': {
          borderBottom: 'none',
        },
      }}
    >
      <Box
        component={RouterLink}
        to={`/products/${item.productId}`}
        sx={{
          width: 80,
          height: 80,
          flexShrink: 0,
          mr: 2,
          position: 'relative',
          overflow: 'hidden',
          textDecoration: 'none',
        }}
      >
        <Box
          component="img"
          src={item.product.images[0]}
          alt={item.product.name}
          sx={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
          }}
        />
      </Box>

      <Box sx={{ flexGrow: 1 }}>
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'flex-start',
          }}
        >
          <Box>
            <Typography
              component={RouterLink}
              to={`/products/${item.productId}`}
              variant="subtitle2"
              sx={{
                textDecoration: 'none',
                color: 'text.primary',
                '&:hover': {
                  color: 'primary.main',
                },
              }}
            >
              {item.product.name}
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
              {item.customizations && Object.values(item.customizations).length > 0
                ? Object.values(item.customizations).join(', ')
                : 'Standard'}
            </Typography>
          </Box>

          <IconButton
            size="small"
            onClick={() => removeItem(item.productId)}
            sx={{ p: 0.5 }}
          >
            <X size={16} />
          </IconButton>
        </Box>

        <Box
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            mt: 1,
          }}
        >
          <Select
            value={item.quantity}
            onChange={handleQuantityChange}
            size="small"
            sx={{
              minWidth: 60,
              height: 32,
              '& .MuiOutlinedInput-input': {
                py: 0.5,
              },
            }}
          >
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((quantity) => (
              <MenuItem key={quantity} value={quantity}>
                {quantity}
              </MenuItem>
            ))}
          </Select>

          <Typography variant="subtitle2">
            ${item.totalPrice.toLocaleString()}
          </Typography>
        </Box>
      </Box>
    </Box>
  );
};

export default CartItem;